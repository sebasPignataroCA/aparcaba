$(document).ready(function(){
    console.log("empezo")

    
});